package com.example.model

import androidx.compose.ui.graphics.Color

data class RobloxUser(
    val username: String,
    val fullName: String,
    val bio: String,
    val avatarResId: Int,
    val postsCount: Int,
    val followersCount: String,
    val followingCount: String
)

data class RobloxComment(
    val id: String,
    val username: String,
    val text: String,
    val timestamp: String = "Just now"
)

data class RobloxPost(
    val id: String,
    val username: String,
    val userAvatarResId: Int,
    val postImageResId: Int,
    val caption: String,
    val likesCount: Int,
    val isLiked: Boolean = false,
    val comments: List<RobloxComment> = emptyList()
)

data class RobloxReel(
    val id: String,
    val username: String,
    val userAvatarResId: Int,
    val videoTitle: String,
    val likesCount: String,
    val commentsCount: String,
    val isLiked: Boolean = false,
    val gradientStart: Color,
    val gradientEnd: Color
)

data class RobloxStory(
    val id: String,
    val username: String,
    val userAvatarResId: Int,
    val isViewed: Boolean = false
)

data class RobloxMessage(
    val id: String,
    val senderUsername: String,
    val text: String,
    val timestamp: String,
    val isSentByMe: Boolean
)

data class RobloxChat(
    val id: String,
    val recipientUsername: String,
    val recipientAvatarResId: Int,
    val recipientStatus: String, // e.g. "Online", "In Game: Bloxburg", "Offline"
    val messages: List<RobloxMessage>,
    val unreadCount: Int = 0
)

