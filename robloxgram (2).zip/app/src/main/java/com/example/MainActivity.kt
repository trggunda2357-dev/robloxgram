package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.MainNavigationScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.screens.DirectMessagesScreen
import com.example.ui.theme.RobloxGramTheme
import com.example.viewmodel.RobloxGramViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Enable true edge-to-edge drawing under system bars
        enableEdgeToEdge()
        
        setContent {
            RobloxGramTheme {
                val navController = rememberNavController()
                val viewModel: RobloxGramViewModel = viewModel()

                NavHost(
                    navController = navController,
                    startDestination = "splash",
                    modifier = Modifier.fillMaxSize()
                ) {
                    // 1. SPLASH SCREEN
                    composable("splash") {
                        SplashScreen(
                            onNavigateToLogin = {
                                navController.navigate("login") {
                                    popUpTo("splash") { inclusive = true }
                                }
                            }
                        )
                    }

                    // 2. LOGIN SCREEN
                    composable("login") {
                        LoginScreen(
                            onNavigateToMain = { username ->
                                navController.navigate("main/$username") {
                                    popUpTo("login") { inclusive = true }
                                }
                            }
                        )
                    }

                    // 3. MAIN APP FLOW WITH BOTTOM NAVIGATION
                    composable(
                        route = "main/{username}",
                        arguments = listOf(navArgument("username") { type = NavType.StringType })
                    ) { backStackEntry ->
                        val username = backStackEntry.arguments?.getString("username") ?: "Guest"
                        MainNavigationScreen(
                            viewModel = viewModel,
                            initialUsername = username,
                            onLogout = {
                                navController.navigate("login") {
                                    popUpTo(0) { inclusive = true }
                                }
                            },
                            onNavigateToMessages = {
                                navController.navigate("direct_messages")
                            }
                        )
                    }

                    // 4. DIRECT MESSAGES SCREEN
                    composable("direct_messages") {
                        DirectMessagesScreen(
                            viewModel = viewModel,
                            onBack = {
                                navController.popBackStack()
                            }
                        )
                    }
                }
            }
        }
    }
}
