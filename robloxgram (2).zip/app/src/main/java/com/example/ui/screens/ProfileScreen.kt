package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GridOn
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.R
import com.example.ui.theme.RobloxBlack
import com.example.ui.theme.RobloxBlueAccent
import com.example.ui.theme.RobloxCardGrey
import com.example.ui.theme.RobloxRed
import com.example.ui.theme.RobloxTextSecondary
import com.example.viewmodel.RobloxGramViewModel

@Composable
fun ProfileScreen(
    viewModel: RobloxGramViewModel,
    onLogout: () -> Unit
) {
    val currentUser by viewModel.currentUser.collectAsState()
    val posts by viewModel.posts.collectAsState()
    val context = LocalContext.current

    var isEditProfileOpen by remember { mutableStateOf(false) }
    var selectedGridPostImage by remember { mutableStateOf<Int?>(null) }

    // Aggregate user-owned images for the portfolio grid
    val portfolioImages = listOf(
        R.drawable.img_post_obby_1783429379157,
        R.drawable.img_post_city_1783429397385,
        R.drawable.img_roblox_splash_1783429347245,
        R.drawable.img_avatar_sigma_1783429362573,
        R.drawable.img_post_obby_1783429379157,
        R.drawable.img_post_city_1783429397385,
        R.drawable.img_roblox_splash_1783429347245,
        R.drawable.img_avatar_sigma_1783429362573,
        R.drawable.img_post_obby_1783429379157,
        R.drawable.img_post_city_1783429397385,
        R.drawable.img_roblox_splash_1783429347245,
        R.drawable.img_app_icon_1783429413169
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(RobloxBlack)
            .testTag("profile_screen")
    ) {
        // App Bar Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = currentUser.username,
                color = Color.White,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )

            // Logout Option
            IconButton(
                onClick = onLogout,
                modifier = Modifier.testTag("logout_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ExitToApp,
                    contentDescription = "Log Out",
                    tint = RobloxRed
                )
            }
        }

        Divider(color = Color(0xFF1D1D23), thickness = 1.dp)

        // Main Profile Header Info
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Profile Avatar with high fidelity cyan ring
                Box(
                    modifier = Modifier
                        .size(86.dp)
                        .border(2.dp, RobloxBlueAccent, CircleShape)
                        .padding(4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = painterResource(id = currentUser.avatarResId),
                        contentDescription = "My Profile Avatar",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(CircleShape)
                    )
                }

                // Status Counts
                Row(
                    modifier = Modifier.weight(1f),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    StatColumn(count = currentUser.postsCount.toString(), label = "Posts")
                    StatColumn(count = currentUser.followersCount, label = "Followers")
                    StatColumn(count = currentUser.followingCount, label = "Following")
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // User info details
            Text(
                text = currentUser.fullName,
                color = Color.White,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = currentUser.bio,
                color = Color.LightGray,
                fontSize = 13.sp,
                lineHeight = 18.sp
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Edit Profile Outlined Button
            OutlinedButton(
                onClick = { isEditProfileOpen = true },
                shape = RoundedCornerShape(8.dp),
                border = ButtonDefaults.outlinedButtonBorder.copy(width = 1.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(38.dp)
                    .testTag("edit_profile_button")
            ) {
                Text(
                    text = "Edit Profile",
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Tab Divider section
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = Icons.Default.GridOn,
                contentDescription = "Posts Grid",
                tint = Color.White,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(32.dp))
            Icon(
                imageVector = Icons.Default.PhotoLibrary,
                contentDescription = "Tags Section",
                tint = Color.Gray,
                modifier = Modifier.size(24.dp)
            )
        }

        Divider(color = Color(0xFF1D1D23), thickness = 1.dp)

        // Portfolio 3-Column Grid View
        LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            contentPadding = PaddingValues(2.dp),
            horizontalArrangement = Arrangement.spacedBy(2.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp),
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            itemsIndexed(portfolioImages) { index, imgResId ->
                Image(
                    painter = painterResource(id = imgResId),
                    contentDescription = "Portfolio image $index",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .aspectRatio(1f)
                        .clickable { selectedGridPostImage = imgResId }
                        .testTag("profile_portfolio_item_$index")
                )
            }
        }
    }

    // Edit Profile Modal Dialog
    if (isEditProfileOpen) {
        EditProfileDialog(
            currentName = currentUser.fullName,
            currentBio = currentUser.bio,
            onSave = { name, bio ->
                viewModel.updateProfile(name, bio)
                isEditProfileOpen = false
                Toast.makeText(context, "Profile updated successfully! ✨", Toast.LENGTH_SHORT).show()
            },
            onDismiss = { isEditProfileOpen = false }
        )
    }

    // Post Expanded Viewer
    selectedGridPostImage?.let { imgId ->
        Dialog(onDismissRequest = { selectedGridPostImage = null }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .testTag("portfolio_detail_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = RobloxCardGrey)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Portfolio Project View",
                            color = Color.White,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = Color.Gray,
                            modifier = Modifier.clickable { selectedGridPostImage = null }
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Image(
                        painter = painterResource(id = imgId),
                        contentDescription = "Project Detail",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(260.dp)
                            .clip(RoundedCornerShape(8.dp))
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "Roblox developers display their creations in dynamic grids. Keep working on outstanding experiences! 🧱🚀",
                        color = Color.LightGray,
                        fontSize = 13.sp,
                        lineHeight = 17.sp
                    )
                }
            }
        }
    }
}

@Composable
fun StatColumn(count: String, label: String) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = count,
            color = Color.White,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = label,
            color = RobloxTextSecondary,
            fontSize = 12.sp,
            fontWeight = FontWeight.Normal
        )
    }
}

@Composable
fun EditProfileDialog(
    currentName: String,
    currentBio: String,
    onSave: (String, String) -> Unit,
    onDismiss: () -> Unit
) {
    var name by remember { mutableStateOf(currentName) }
    var bio by remember { mutableStateOf(currentBio) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .testTag("edit_profile_dialog"),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = RobloxCardGrey)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .fillMaxWidth()
            ) {
                Text(
                    text = "Edit Profile details",
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Full Name Input
                Text("Full Name", color = RobloxTextSecondary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    singleLine = true,
                    shape = RoundedCornerShape(8.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = RobloxBlueAccent,
                        unfocusedBorderColor = Color.DarkGray,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("edit_name_input")
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Bio Input
                Text("Bio description", color = RobloxTextSecondary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = bio,
                    onValueChange = { bio = it },
                    maxLines = 3,
                    shape = RoundedCornerShape(8.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = RobloxBlueAccent,
                        unfocusedBorderColor = Color.DarkGray,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("edit_bio_input")
                )

                Spacer(modifier = Modifier.height(24.dp))

                // Actions Button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    Text(
                        text = "Cancel",
                        color = Color.Gray,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .clickable { onDismiss() }
                            .padding(12.dp)
                            .testTag("edit_cancel_btn")
                    )

                    Spacer(modifier = Modifier.width(16.dp))

                    Button(
                        onClick = { onSave(name, bio) },
                        colors = ButtonDefaults.buttonColors(containerColor = RobloxBlueAccent),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("edit_save_btn")
                    ) {
                        Text("Save", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
