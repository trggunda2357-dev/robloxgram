package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Dark Premium Roblox Palette
val RobloxBlack = Color(0xFF000000)
val RobloxDarkGrey = Color(0xFF0F0F12)
val RobloxCardGrey = Color(0xFF1B1B1F)
val RobloxRed = Color(0xFFFF4545)
val RobloxBlueAccent = Color(0xFF29B6F6)
val RobloxTextPrimary = Color(0xFFFFFFFF)
val RobloxTextSecondary = Color(0x99FFFFFF)
val RobloxBorder = Color(0xFF2C2C32)

// Original Material 3 placeholders
val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)
val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)
