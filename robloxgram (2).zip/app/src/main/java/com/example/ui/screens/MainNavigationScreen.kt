package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Movie
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import com.example.ui.theme.RobloxBlack
import com.example.ui.theme.RobloxCardGrey
import com.example.ui.theme.RobloxRed
import com.example.ui.theme.RobloxTextSecondary
import com.example.viewmodel.RobloxGramViewModel

@Composable
fun MainNavigationScreen(
    viewModel: RobloxGramViewModel,
    initialUsername: String,
    onLogout: () -> Unit,
    onNavigateToMessages: () -> Unit
) {
    var selectedIndex by remember { mutableIntStateOf(0) }

    val tabs = listOf(
        TabItem("Home", Icons.Default.Home, Icons.Outlined.Home),
        TabItem("Search", Icons.Default.Search, Icons.Outlined.Search),
        TabItem("Reels", Icons.Default.Movie, Icons.Outlined.Movie),
        TabItem("Profile", Icons.Default.Person, Icons.Outlined.Person)
    )

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            NavigationBar(
                containerColor = RobloxBlack,
                tonalElevation = 8.dp,
                modifier = Modifier
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .testTag("bottom_nav_bar")
            ) {
                tabs.forEachIndexed { index, tab ->
                    val isSelected = selectedIndex == index
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { selectedIndex = index },
                        icon = {
                            Icon(
                                imageVector = if (isSelected) tab.selectedIcon else tab.unselectedIcon,
                                contentDescription = tab.title,
                                tint = if (isSelected) Color.White else RobloxTextSecondary
                            )
                        },
                        label = {
                            Text(
                                text = tab.title.uppercase(),
                                color = if (isSelected) Color.White else RobloxTextSecondary,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = (-0.5).sp,
                                modifier = Modifier.testTag("nav_label_${tab.title.lowercase()}")
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            indicatorColor = RobloxCardGrey
                        )
                    )
                }
            }
        },
        contentWindowInsets = WindowInsets(0, 0, 0, 0)
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(RobloxBlack)
                .padding(innerPadding)
        ) {
            when (selectedIndex) {
                0 -> HomeScreen(
                    viewModel = viewModel,
                    onNavigateToMessages = onNavigateToMessages
                )
                1 -> SearchScreen(viewModel = viewModel)
                2 -> ReelsScreen(viewModel = viewModel)
                3 -> ProfileScreen(viewModel = viewModel, onLogout = onLogout)
            }
        }
    }
}

private data class TabItem(
    val title: String,
    val selectedIcon: androidx.compose.ui.graphics.vector.ImageVector,
    val unselectedIcon: androidx.compose.ui.graphics.vector.ImageVector
)
