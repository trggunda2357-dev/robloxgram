package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Send
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SheetState
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.model.RobloxPost
import com.example.model.RobloxStory
import com.example.ui.theme.RobloxBlack
import com.example.ui.theme.RobloxBlueAccent
import com.example.ui.theme.RobloxCardGrey
import com.example.ui.theme.RobloxRed
import com.example.ui.theme.RobloxTextSecondary
import com.example.viewmodel.RobloxGramViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: RobloxGramViewModel,
    onNavigateToMessages: () -> Unit
) {
    val posts by viewModel.posts.collectAsState()
    val stories by viewModel.stories.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()
    val context = LocalContext.current

    var selectedStoryForView by remember { mutableStateOf<RobloxStory?>(null) }
    var activePostForComments by remember { mutableStateOf<RobloxPost?>(null) }
    val bottomSheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val coroutineScope = rememberCoroutineScope()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(RobloxBlack)
            .testTag("home_screen")
    ) {
        // App Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(RobloxBlack)
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "ROBLOXGRAM",
                color = Color.White,
                fontSize = 26.sp,
                fontWeight = FontWeight.Black,
                fontStyle = FontStyle.Italic,
                letterSpacing = (-1.5).sp,
                modifier = Modifier.clickable {
                    Toast.makeText(context, "Welcome to RobloxGram! 🚀", Toast.LENGTH_SHORT).show()
                }
            )

            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = {
                        Toast.makeText(context, "Loved RobloxGram! ❤️", Toast.LENGTH_SHORT).show()
                    }
                ) {
                    Icon(
                        imageVector = Icons.Default.Favorite,
                        contentDescription = "Notifications",
                        tint = RobloxRed
                    )
                }

                IconButton(
                    onClick = onNavigateToMessages
                ) {
                    Icon(
                        imageVector = Icons.Default.ChatBubbleOutline,
                        contentDescription = "Messages",
                        tint = Color.White
                    )
                }
            }
        }

        Divider(color = Color(0xFF1D1D23), thickness = 1.dp)

        // Main Feed LazyColumn
        LazyColumn(
            modifier = Modifier.fillMaxSize()
        ) {
            // Stories Section
            item {
                StoriesRow(
                    stories = stories,
                    onStoryClick = { story ->
                        viewModel.viewStory(story.id)
                        selectedStoryForView = story
                    }
                )
                Divider(color = Color(0xFF1D1D23), thickness = 1.dp)
            }

            // Post Items
            items(posts, key = { it.id }) { post ->
                PostItem(
                    post = post,
                    onLikeToggle = { viewModel.toggleLikePost(post.id) },
                    onCommentsClick = { activePostForComments = post }
                )
            }

            // Empty spacing at bottom
            item {
                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }

    // Story Viewer Dialog
    selectedStoryForView?.let { story ->
        StoryViewerDialog(
            story = story,
            onDismiss = { selectedStoryForView = null }
        )
    }

    // Bottom Sheet for Comments
    activePostForComments?.let { postState ->
        // Retrieve live reference of post to update comments reactively
        val currentPost = posts.find { it.id == postState.id } ?: postState
        
        ModalBottomSheet(
            onDismissRequest = { activePostForComments = null },
            sheetState = bottomSheetState,
            containerColor = RobloxCardGrey,
            contentColor = Color.White,
            modifier = Modifier.fillMaxHeight(0.75f)
        ) {
            CommentSheetContent(
                post = currentPost,
                currentUserUsername = currentUser.username,
                onAddComment = { commentText ->
                    viewModel.addComment(currentPost.id, commentText, currentUser.username)
                },
                onDismiss = {
                    coroutineScope.launch {
                        bottomSheetState.hide()
                    }.invokeOnCompletion {
                        activePostForComments = null
                    }
                }
            )
        }
    }
}

@Composable
fun StoriesRow(
    stories: List<RobloxStory>,
    onStoryClick: (RobloxStory) -> Unit
) {
    LazyRow(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp, horizontal = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(stories) { story ->
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .clickable { onStoryClick(story) }
                    .padding(horizontal = 4.dp)
            ) {
                // Gradient border to simulate Instagram unread story
                val gradientColors = if (story.isViewed) {
                    listOf(Color.DarkGray, Color.Gray)
                } else {
                    listOf(Color(0xFF833AB4), Color(0xFFF77737), Color(0xFFFCAF45))
                }

                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .border(
                            width = 2.5.dp,
                            brush = Brush.linearGradient(gradientColors),
                            shape = CircleShape
                        )
                        .padding(4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = painterResource(id = story.userAvatarResId),
                        contentDescription = "${story.username} avatar",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(CircleShape)
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = if (story.username.length > 10) story.username.take(8) + ".." else story.username,
                    color = if (story.isViewed) Color.Gray else Color.White,
                    fontSize = 11.sp,
                    fontWeight = if (story.isViewed) FontWeight.Normal else FontWeight.Medium
                )
            }
        }
    }
}

@Composable
fun PostItem(
    post: RobloxPost,
    onLikeToggle: () -> Unit,
    onCommentsClick: () -> Unit
) {
    var likeBounced by remember { mutableStateOf(false) }
    val likeScale by animateFloatAsState(
        targetValue = if (likeBounced) 1.4f else 1f,
        animationSpec = tween(durationMillis = 150),
        finishedListener = { likeBounced = false }
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 8.dp)
            .testTag("post_item_${post.id}"),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF16161A)),
        shape = RoundedCornerShape(24.dp)
    ) {
        Column(modifier = Modifier.padding(bottom = 12.dp)) {
            // Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Image(
                        painter = painterResource(id = post.userAvatarResId),
                        contentDescription = "Post User Avatar",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                    )

                    Spacer(modifier = Modifier.width(10.dp))

                    Text(
                        text = post.username,
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                IconButton(onClick = {}) {
                    Icon(
                        imageVector = Icons.Default.MoreVert,
                        contentDescription = "More Options",
                        tint = Color.Gray
                    )
                }
            }

            // Post Image with custom margins and rounded-2xl corners
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(340.dp)
                    .padding(horizontal = 4.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFF0C0C0F))
            ) {
                Image(
                    painter = painterResource(id = post.postImageResId),
                    contentDescription = "Roblox Feed Post Image",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )

                // Live Stream Indicator overlay
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(12.dp)
                        .background(Color.Black.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .background(Color(0xFFFF4545), CircleShape)
                        )
                        Text(
                            text = "LIVE • ${post.likesCount} VIEWERS",
                            color = Color.White,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp
                        )
                    }
                }
            }

            // Actions Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = {
                        likeBounced = true
                        onLikeToggle()
                    },
                    modifier = Modifier.scale(likeScale)
                ) {
                    Icon(
                        imageVector = if (post.isLiked) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = "Like Post",
                        tint = if (post.isLiked) RobloxRed else Color.White
                    )
                }

                IconButton(onClick = onCommentsClick) {
                    Icon(
                        imageVector = Icons.Outlined.ChatBubbleOutline,
                        contentDescription = "Open Comments",
                        tint = Color.White
                    )
                }

                IconButton(onClick = {}) {
                    Icon(
                        imageVector = Icons.Outlined.Send,
                        contentDescription = "Send Post",
                        tint = Color.White
                    )
                }
            }

            // Stats & Caption
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 2.dp)
            ) {
                Text(
                    text = "${post.likesCount} LIKES",
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 0.5.sp
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Caption with rich bold username
                val annotatedString = buildAnnotatedString {
                    withStyle(style = SpanStyle(fontWeight = FontWeight.Bold, color = Color.White)) {
                        append("${post.username} ")
                    }
                    append(post.caption)
                }

                Text(
                    text = annotatedString,
                    color = Color.White,
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )

                if (post.comments.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "VIEW ALL ${post.comments.size} COMMENTS",
                        color = RobloxTextSecondary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp,
                        modifier = Modifier
                            .clickable { onCommentsClick() }
                            .padding(vertical = 2.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun StoryViewerDialog(
    story: RobloxStory,
    onDismiss: () -> Unit
) {
    var progress by remember { mutableStateOf(0f) }

    LaunchedEffect(key1 = true) {
        val duration = 3000 // 3 seconds
        val step = 100
        for (i in 0..duration step step) {
            delay(step.toLong())
            progress = i.toFloat() / duration
        }
        onDismiss()
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
        ) {
            // Fill background with Story Image
            Image(
                painter = painterResource(id = story.userAvatarResId),
                contentDescription = "Story Media",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )

            // Dark overlay for readability
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(Color(0x88000000), Color.Transparent, Color(0x66000000))
                        )
                    )
            )

            // Top Progress Bar and Header
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 28.dp, start = 16.dp, end = 16.dp)
                    .align(Alignment.TopCenter)
            ) {
                // Horizontal linear bar
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(3.dp)
                        .background(Color.White.copy(alpha = 0.3f), RoundedCornerShape(2.dp))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(progress)
                            .height(3.dp)
                            .background(RobloxRed, RoundedCornerShape(2.dp))
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Image(
                            painter = painterResource(id = story.userAvatarResId),
                            contentDescription = "Story Owner",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = story.username,
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close Story",
                            tint = Color.White
                        )
                    }
                }
            }

            // Bottom text / engagement helper
            Text(
                text = "@${story.username} is enjoying their day in Roblox Gram! 👾📱",
                color = Color.White,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 60.dp, start = 24.dp, end = 24.dp)
            )
        }
    }
}

@Composable
fun CommentSheetContent(
    post: RobloxPost,
    currentUserUsername: String,
    onAddComment: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var commentText by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Comment title
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Comments (${post.comments.size})",
                color = Color.White,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )

            IconButton(onClick = onDismiss) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Close",
                    tint = Color.Gray
                )
            }
        }

        Divider(color = Color(0xFF2C2C35), modifier = Modifier.padding(vertical = 12.dp))

        // Comment List
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (post.comments.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(40.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "No comments yet. Start the conversation! 💬",
                            color = Color.Gray,
                            fontSize = 14.sp
                        )
                    }
                }
            } else {
                items(post.comments) { comment ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.Top
                    ) {
                        // Custom colorful avatar for commentators
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF2C2C35)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = comment.username.take(1).uppercase(),
                                color = RobloxBlueAccent,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = comment.username,
                                    color = Color.White,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = comment.timestamp,
                                    color = Color.Gray,
                                    fontSize = 10.sp
                                )
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = comment.text,
                                color = Color.LightGray,
                                fontSize = 13.sp,
                                lineHeight = 17.sp
                            )
                        }
                    }
                }
            }
        }

        Divider(color = Color(0xFF2C2C35), modifier = Modifier.padding(vertical = 12.dp))

        // Add Comment Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = commentText,
                onValueChange = { commentText = it },
                placeholder = { Text("Add comment as @$currentUserUsername..", color = Color.Gray, fontSize = 13.sp) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = {
                    if (commentText.isNotBlank()) {
                        onAddComment(commentText)
                        commentText = ""
                    }
                }),
                shape = RoundedCornerShape(20.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color.DarkGray,
                    unfocusedBorderColor = Color.DarkGray,
                    focusedContainerColor = Color(0xFF151518),
                    unfocusedContainerColor = Color(0xFF151518),
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                ),
                modifier = Modifier.weight(1f)
            )

            Spacer(modifier = Modifier.width(8.dp))

            IconButton(
                onClick = {
                    if (commentText.isNotBlank()) {
                        onAddComment(commentText)
                        commentText = ""
                    }
                },
                modifier = Modifier
                    .clip(CircleShape)
                    .background(RobloxBlueAccent)
            ) {
                Icon(
                    imageVector = Icons.Default.Send,
                    contentDescription = "Post Comment",
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}
