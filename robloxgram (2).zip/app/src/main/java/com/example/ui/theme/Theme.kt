package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val RobloxDarkColorScheme = darkColorScheme(
    primary = RobloxRed,
    onPrimary = Color.White,
    secondary = RobloxBlueAccent,
    onSecondary = Color.White,
    background = RobloxBlack,
    onBackground = Color.White,
    surface = RobloxDarkGrey,
    onSurface = Color.White,
    surfaceVariant = RobloxCardGrey,
    onSurfaceVariant = Color.White,
    outline = RobloxBorder
)

// Standard light scheme mapping to stay dark-dominant, or support light for fallback
private val RobloxLightColorScheme = darkColorScheme(
    primary = RobloxRed,
    onPrimary = Color.White,
    secondary = RobloxBlueAccent,
    onSecondary = Color.White,
    background = Color(0xFF0C0C0F),
    onBackground = Color.White,
    surface = Color(0xFF16161A),
    onSurface = Color.White,
    surfaceVariant = Color(0xFF222228),
    onSurfaceVariant = Color.White,
    outline = Color(0xFF33333F)
)

@Composable
fun RobloxGramTheme(
    darkTheme: Boolean = true, // Force dark by default to respect Roblox's high-contrast dark style
    dynamicColor: Boolean = false, // Disable dynamic colors to preserve brand-specific Roblox styling
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) RobloxDarkColorScheme else RobloxLightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

// Retain old name for preview backwards compatibility if needed
@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = true,
    content: @Composable () -> Unit,
) {
    RobloxGramTheme(darkTheme = darkTheme, dynamicColor = dynamicColor, content = content)
}
