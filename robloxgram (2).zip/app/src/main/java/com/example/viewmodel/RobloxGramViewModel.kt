package com.example.viewmodel

import androidx.compose.ui.graphics.Color
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.R
import com.example.model.RobloxComment
import com.example.model.RobloxPost
import com.example.model.RobloxReel
import com.example.model.RobloxStory
import com.example.model.RobloxUser
import com.example.model.RobloxMessage
import com.example.model.RobloxChat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay

class RobloxGramViewModel : ViewModel() {

    // Direct Message Chats List
    private val _chats = MutableStateFlow(
        listOf(
            RobloxChat(
                id = "chat_builderman",
                recipientUsername = "build_master",
                recipientAvatarResId = R.drawable.img_post_obby_1783429379157,
                recipientStatus = "In Game: Bloxburg",
                messages = listOf(
                    RobloxMessage("m1_1", "build_master", "Yo, loved your new obby! How did you get the glowing neon to pulse?", "9:41 AM", false),
                    RobloxMessage("m1_2", "sigma_developer", "Thanks builderman! I used a custom TweenService configuration with a loop! ⚡", "9:42 AM", true),
                    RobloxMessage("m1_3", "build_master", "That is brilliant. We should collab on a cyberpunk tycoon project next week!", "9:43 AM", false)
                ),
                unreadCount = 1
            ),
            RobloxChat(
                id = "chat_noob",
                recipientUsername = "roblox_noob",
                recipientAvatarResId = R.drawable.img_roblox_splash_1783429347245,
                recipientStatus = "Online",
                messages = listOf(
                    RobloxMessage("m2_1", "roblox_noob", "hey bro! can u give me free robux pls? 🥺😅", "Yesterday", false),
                    RobloxMessage("m2_2", "sigma_developer", "Haha, I cannot do that, but I can help you learn how to code your first game! 🧱", "Yesterday", true),
                    RobloxMessage("m2_3", "roblox_noob", "omg really?? that would be so epic! teach me master!", "Yesterday", false)
                ),
                unreadCount = 0
            ),
            RobloxChat(
                id = "chat_adopt",
                recipientUsername = "adopt_me_fan",
                recipientAvatarResId = R.drawable.img_roblox_splash_1783429347245,
                recipientStatus = "Offline",
                messages = listOf(
                    RobloxMessage("m3_1", "adopt_me_fan", "Hey, do you have any neon legendary pets for trade? 🦄", "2 days ago", false),
                    RobloxMessage("m3_2", "sigma_developer", "I'm mostly coding tycoon maps right now, but I might have some extra items!", "2 days ago", true)
                ),
                unreadCount = 0
            )
        )
    )
    val chats: StateFlow<List<RobloxChat>> = _chats.asStateFlow()

    // Current logged in user
    private val _currentUser = MutableStateFlow(
        RobloxUser(
            username = "sigma_developer",
            fullName = "Sigma Developer",
            bio = "Building games & apps. Hard work pays off. 🔥⚡",
            avatarResId = R.drawable.img_avatar_sigma_1783429362573,
            postsCount = 12,
            followersCount = "10K",
            followingCount = "357"
        )
    )
    val currentUser: StateFlow<RobloxUser> = _currentUser.asStateFlow()

    // Stories list
    private val _stories = MutableStateFlow(
        listOf(
            RobloxStory("s1", "adopt_me_fan", R.drawable.img_roblox_splash_1783429347245, false),
            RobloxStory("s2", "build_master", R.drawable.img_post_obby_1783429379157, false),
            RobloxStory("s3", "bloxburg_builder", R.drawable.img_post_city_1783429397385, false),
            RobloxStory("s4", "roblox_noob", R.drawable.img_roblox_splash_1783429347245, false),
            RobloxStory("s5", "royale_highness", R.drawable.img_avatar_sigma_1783429362573, false),
            RobloxStory("s6", "avatar_guru", R.drawable.img_post_obby_1783429379157, false),
            RobloxStory("s7", "obby_pro", R.drawable.img_post_city_1783429397385, false),
            RobloxStory("s8", "tycoon_king", R.drawable.img_roblox_splash_1783429347245, false)
        )
    )
    val stories: StateFlow<List<RobloxStory>> = _stories.asStateFlow()

    // Feed Posts list
    private val _posts = MutableStateFlow(
        listOf(
            RobloxPost(
                id = "p1",
                username = "sigma_developer",
                userAvatarResId = R.drawable.img_avatar_sigma_1783429362573,
                postImageResId = R.drawable.img_post_obby_1783429379157,
                caption = "Just beat the world record on the glowing neon death run! Who wants to race? 🔥🏁 #RobloxObby #Level100",
                likesCount = 457,
                isLiked = false,
                comments = listOf(
                    RobloxComment("c1_1", "adopt_me_fan", "This obby looks insane! Teach me your ways! 🙌"),
                    RobloxComment("c1_2", "roblox_noob", "Whaaat, I fell on stage 2 like ten times lmao"),
                    RobloxComment("c1_3", "build_master", "Epic lighting configuration! Very aesthetic.")
                )
            ),
            RobloxPost(
                id = "p2",
                username = "bloxburg_builder",
                userAvatarResId = R.drawable.img_roblox_splash_1783429347245,
                postImageResId = R.drawable.img_post_city_1783429397385,
                caption = "Finished building our cyberpunk city hang-out space in Bloxburg! Grand opening tonight at 8 PM EST. Come hang out with the devs! 🏙️⚡ #Bloxburg #Cyberpunk",
                likesCount = 1205,
                isLiked = true,
                comments = listOf(
                    RobloxComment("c2_1", "sigma_developer", "I'll definitely check this out! Design looks spectacular!"),
                    RobloxComment("c2_2", "royale_highness", "OMG the neon signs are gorgeous!")
                )
            ),
            RobloxPost(
                id = "p3",
                username = "roblox_noob",
                userAvatarResId = R.drawable.img_roblox_splash_1783429347245,
                postImageResId = R.drawable.img_roblox_splash_1783429347245,
                caption = "Met my favourite developer today! RobloxGram is officially the coolest social platform in the metaverse. 🤩🚀 #MetTheirDevs",
                likesCount = 88,
                isLiked = false,
                comments = listOf(
                    RobloxComment("c3_1", "sigma_developer", "Thanks for coming by! Appreciate the support! 👊")
                )
            )
        )
    )
    val posts: StateFlow<List<RobloxPost>> = _posts.asStateFlow()

    // Reels list
    private val _reels = MutableStateFlow(
        listOf(
            RobloxReel(
                id = "r1",
                username = "obby_pro",
                userAvatarResId = R.drawable.img_post_obby_1783429379157,
                videoTitle = "Insane speedrun skip in Roblox Tower of Hell! ⏱️💀 #shorts #speedrun",
                likesCount = "1.2M",
                commentsCount = "4.5K",
                isLiked = false,
                gradientStart = Color(0xFFFF416C),
                gradientEnd = Color(0xFFFF4B2B)
            ),
            RobloxReel(
                id = "r2",
                username = "bloxburg_builder",
                userAvatarResId = R.drawable.img_post_city_1783429397385,
                videoTitle = "Time-lapse build of a $500,000 modern mansion! 🛠️🏡 #bloxburgbuilds",
                likesCount = "850K",
                commentsCount = "3.2K",
                isLiked = true,
                gradientStart = Color(0xFF1F1C2C),
                gradientEnd = Color(0xFF928DAB)
            ),
            RobloxReel(
                id = "r3",
                username = "adopt_me_fan",
                userAvatarResId = R.drawable.img_roblox_splash_1783429347245,
                videoTitle = "Trading my mega neon dragon for THIS?! Unbelievable trade! 🐉😱 #adoptme",
                likesCount = "420K",
                commentsCount = "9.8K",
                isLiked = false,
                gradientStart = Color(0xFF11998E),
                gradientEnd = Color(0xFF38EF7D)
            ),
            RobloxReel(
                id = "r4",
                username = "sigma_developer",
                userAvatarResId = R.drawable.img_avatar_sigma_1783429362573,
                videoTitle = "Preview of my brand new Roblox UI animations using Compose-like principles! 📱🔥 #devlog",
                likesCount = "95K",
                commentsCount = "1.1K",
                isLiked = false,
                gradientStart = Color(0xFF00c6ff),
                gradientEnd = Color(0xFF0072ff)
            ),
            RobloxReel(
                id = "r5",
                username = "royale_highness",
                userAvatarResId = R.drawable.img_avatar_sigma_1783429362573,
                videoTitle = "Rating the new summer update outfits! Which one is your fav? 👗✨ #royalehigh",
                likesCount = "310K",
                commentsCount = "5.5K",
                isLiked = false,
                gradientStart = Color(0xFFf857a6),
                gradientEnd = Color(0xFFff5858)
            )
        )
    )
    val reels: StateFlow<List<RobloxReel>> = _reels.asStateFlow()

    // Search query and filter state
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedSearchCategory = MutableStateFlow("All")
    val selectedSearchCategory: StateFlow<String> = _selectedSearchCategory.asStateFlow()

    // Filtered search results
    val searchResults: StateFlow<List<RobloxPost>> = combine(
        _searchQuery,
        _selectedSearchCategory,
        _posts
    ) { query, category, postsList ->
        if (query.isEmpty() && category == "All") {
            postsList
        } else {
            postsList.filter { post ->
                val matchesQuery = post.caption.contains(query, ignoreCase = true) ||
                        post.username.contains(query, ignoreCase = true)
                val matchesCategory = when (category) {
                    "All" -> true
                    "Obby" -> post.caption.contains("obby", ignoreCase = true)
                    "Builds" -> post.caption.contains("build", ignoreCase = true) || post.caption.contains("bloxburg", ignoreCase = true)
                    "Metaverse" -> post.caption.contains("metaverse", ignoreCase = true) || post.caption.contains("dev", ignoreCase = true)
                    else -> true
                }
                matchesQuery && matchesCategory
            }
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // State actions
    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setSearchCategory(category: String) {
        _selectedSearchCategory.value = category
    }

    fun toggleLikePost(postId: String) {
        _posts.value = _posts.value.map { post ->
            if (post.id == postId) {
                val newIsLiked = !post.isLiked
                val newLikesCount = if (newIsLiked) post.likesCount + 1 else post.likesCount - 1
                post.copy(isLiked = newIsLiked, likesCount = newLikesCount)
            } else {
                post
            }
        }
    }

    fun addComment(postId: String, text: String, author: String) {
        if (text.isBlank()) return
        _posts.value = _posts.value.map { post ->
            if (post.id == postId) {
                val newComment = RobloxComment(
                    id = "c_${post.id}_${post.comments.size + 1}",
                    username = author,
                    text = text
                )
                post.copy(comments = post.comments + newComment)
            } else {
                post
            }
        }
    }

    fun toggleLikeReel(reelId: String) {
        _reels.value = _reels.value.map { reel ->
            if (reel.id == reelId) {
                reel.copy(isLiked = !reel.isLiked)
            } else {
                reel
            }
        }
    }

    fun updateProfile(fullName: String, bio: String) {
        _currentUser.value = _currentUser.value.copy(
            fullName = fullName,
            bio = bio
        )
    }

    fun viewStory(storyId: String) {
        _stories.value = _stories.value.map { story ->
            if (story.id == storyId) {
                story.copy(isViewed = true)
            } else {
                story
            }
        }
    }

    fun sendMessage(chatId: String, text: String) {
        if (text.isBlank()) return
        
        val now = "Just now"
        val newMessage = RobloxMessage(
            id = "msg_${System.currentTimeMillis()}",
            senderUsername = _currentUser.value.username,
            text = text,
            timestamp = now,
            isSentByMe = true
        )
        
        // Append message
        _chats.value = _chats.value.map { chat ->
            if (chat.id == chatId) {
                chat.copy(
                    messages = chat.messages + newMessage,
                    unreadCount = 0
                )
            } else {
                chat
            }
        }
        
        // Launch automatic simulated reply coroutine
        viewModelScope.launch {
            delay(1500) // Delay of 1.5 seconds for realistic feel
            
            val responseText = getSimulatedReply(chatId, text)
            val replyMessage = RobloxMessage(
                id = "msg_${System.currentTimeMillis()}",
                senderUsername = _chats.value.find { it.id == chatId }?.recipientUsername ?: "Friend",
                text = responseText,
                timestamp = "Just now",
                isSentByMe = false
            )
            
            _chats.value = _chats.value.map { chat ->
                if (chat.id == chatId) {
                    chat.copy(
                        messages = chat.messages + replyMessage,
                        unreadCount = 0
                    )
                } else {
                    chat
                }
            }
        }
    }

    private fun getSimulatedReply(chatId: String, query: String): String {
        val lowercaseQuery = query.lowercase()
        return when {
            lowercaseQuery.contains("hello") || lowercaseQuery.contains("hey") || lowercaseQuery.contains("hi") -> {
                "Hey there! What are you building today in Roblox Studio? 🧱🚀"
            }
            lowercaseQuery.contains("collab") || lowercaseQuery.contains("team") || lowercaseQuery.contains("build") -> {
                "Oh, definitely! Let's build a new obby or survival island together. I'll boot up Team Create! 🎮💻"
            }
            lowercaseQuery.contains("robux") -> {
                "Lol! No robux here, but maybe we can make a game that goes viral on Roblox and earn millions of Robux! 🤑🏆"
            }
            lowercaseQuery.contains("obby") -> {
                "I love obbies! We should add moving lava blocks and lasers. Roblox Studio scripting is so powerful!"
            }
            lowercaseQuery.contains("bloxburg") -> {
                "Your Bloxburg layouts are top-tier! Let's construct a massive mansion next! 🏡🎨"
            }
            lowercaseQuery.contains("how") || lowercaseQuery.contains("why") || lowercaseQuery.contains("script") -> {
                "Let's look at Lua scripting! We can script custom sound effects and part colliders to make it fully interactive. ⚡🤖"
            }
            else -> {
                "Awesome! Roblox Gram is so smooth. Let's keep working on epic projects! 👾🛸"
            }
        }
    }
    
    fun markChatAsRead(chatId: String) {
        _chats.value = _chats.value.map { chat ->
            if (chat.id == chatId) {
                chat.copy(unreadCount = 0)
            } else {
                chat
            }
        }
    }
}
